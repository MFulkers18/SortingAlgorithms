

public class LinkedList<T> implements List<T> {
	private LinkedListNode<T>root = new LinkedListNode<>();
	
	LinkedList(T data){
		root.setData(data);
	}
	
	LinkedList(){};
	
	
	private void setRoot(LinkedListNode<T> root) {
		this.root=root;
	}
	
	
	private LinkedListNode<T> getLastNode(){
		LinkedListNode<T> lastNode = root;
		
		while(lastNode.getPointer()!=null) {
			lastNode = lastNode.getPointer();
		}
		
		return lastNode;
	}
	
	public String toString() {
		String string = "";
		LinkedListNode<T> node = root;
		while(node.getPointer()!=null) {
			string+=(node.getData()+"->");
			node = node.getPointer();
		}
		string+=(node.getData());
		return string;
	}
	
	@Override
	public T getFirst() {
		return root.getData();
	}

	
	@Override
	public LinkedListNode<T> getFirstNode() {
		return root;
	}

	
	@Override
	public T getLast() {
		return getLastNode().getData();
	}

	
	@Override
	public void insertFirst(T data) {
		if(root.getData()==null) {
			root.setData(data);
		}
		else {
			LinkedListNode<T> firstNode = new LinkedListNode<>(data, root);
			setRoot(firstNode);
		}
	}

	
	@Override
	public void insertLast(T data) {
		if(root.getData()==null) {
			root.setData(data);
		}
		else {
			LinkedListNode<T> lastNode = new LinkedListNode<>(data,null);
			getLastNode().setPointer(lastNode);
		}
	}

	
	@Override
	public void deleteFirst() {
		setRoot(root.getPointer());
	}

	
	@Override
	public void deleteLast() {
		LinkedListNode<T> node = root;
		
		while(node.getPointer().getPointer()!=null) {
			node = node.getPointer();
		}
		
		node.setPointer(null);
	}
	
	
	@Override
	public void deleteNext(LinkedListNode<T> currentNode) {
		LinkedListNode<T> nextNode = currentNode.getPointer().getPointer();
		currentNode.setPointer(nextNode);
	}

	
	@Override
	public int size() {
		if(isEmpty()) {
			return 0;
		}
		else {
			if(root.getData()!= null && root.getPointer()==null) {
				return 1;
			}
			else {
				int i=0;
				LinkedListNode<T> node = root;
				
				while(node.getPointer()!=null) {
					i++;
					node = node.getPointer();
				}
				return i;
			}
		}
	}

	
	@Override
	public boolean isEmpty() {
		return root.getData()==null && root.getPointer()==null;
	}

}
