

public class LinkedListNode<T>{
	private T data;
	private LinkedListNode<T> pointer;
	
	LinkedListNode(T data, LinkedListNode<T> pointer){
		this.data=data;
		this.pointer=pointer;
	}
	
	LinkedListNode(){};
	
	LinkedListNode(T data){
		this.data=data;
	}
	
	public T getData() {
		return data;
	}
	
	public LinkedListNode<T> getPointer(){
		return pointer;
	}
	
	public void setData(T data) {
		this.data = data;
	}
	
	public void setPointer(LinkedListNode<T> pointer) {
		this.pointer=pointer;
	}
}
