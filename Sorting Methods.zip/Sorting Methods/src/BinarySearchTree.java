

public interface BinarySearchTree<T> {
	public void insert(T data);
	
	public BinaryTreeNode<T> search(T data);
	
	public T minElement();
	
	public T maxElemenmt();
	
	public BinaryTreeNode<T> predecessor(BinaryTreeNode<T> node);
	
	public BinaryTreeNode<T> sucessor(BinaryTreeNode<T> node);
	
	public void delete(BinaryTreeNode<T> node);
	
}
