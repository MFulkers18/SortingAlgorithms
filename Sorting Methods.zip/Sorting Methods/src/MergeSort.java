

public class MergeSort implements Sorter {
	
	private static void divide(BinaryTreeNode<int[]>node) {
		int[] arrayToSort = node.getData();
		if(arrayToSort.length >1) {
			int arrayMid = arrayToSort.length/2;
			int[] leftArray = new int[arrayMid];
			int[] rightArray;
			
			for(int i=0;i<arrayMid;i++) {
				leftArray[i] = arrayToSort[i];
			}
			
			if(arrayToSort.length % 2==0) {
				rightArray = new int[arrayMid];
			}
			else {
				rightArray = new int[arrayMid+1];
			}
			
			for(int j = 0;arrayMid<arrayToSort.length;arrayMid++) {
				rightArray[j] = arrayToSort[arrayMid];
				j++;
			}
			
			BinaryTreeNode<int[]>leftChild = new DefaultBinaryTreeNode<>(leftArray);
			BinaryTreeNode<int[]> rightChild= new DefaultBinaryTreeNode<>(rightArray);
			node.setLeftChild(leftChild);
			node.setRightChild(rightChild);
			
			divide(node.getLeftChild());
			divide(node.getRightChild());
		}
	}
	
	
	private static int[] mergeArrays(int[] leftArray, int[] rightArray) {
		int i = 0;
		int j = 0;
		int k = 0;
		int[] sortedArray = new int[leftArray.length+rightArray.length];
		
		while(i<leftArray.length && j<rightArray.length) {
			if(leftArray[i]<rightArray[j]) {
				sortedArray[k] = leftArray[i];
				k++;
				i++;
			}
			else {
				sortedArray[k] = rightArray[j];
				k++;
				j++;
			}
		}
		
		if(i<leftArray.length) {
			for(int n = i;n<leftArray.length;n++) {
				sortedArray[k] = leftArray[n];
				k++;
			}
		}
		else {
			for(int m=j;m<rightArray.length;m++ ) {
				sortedArray[k] = rightArray[m];
				k++;
			}
		}
		return sortedArray;
	}
	
	
	private static void mergeNodes(BinaryTreeNode<int[]>node) {
		if(node.getLeftChild().isLeaf() && node.getRightChild().isLeaf()) {
			node.setData(mergeArrays(node.getLeftChild().getData(),node.getRightChild().getData()));
			node.setLeftChild(null);
			node.setRightChild(null);
		}
		else {
			if(node.getLeftChild().isLeaf()) {
				mergeNodes(node.getRightChild());
				mergeNodes(node);
			}
			else {
				mergeNodes(node.getLeftChild());
				mergeNodes(node.getRightChild());
				mergeNodes(node);
			}
		}
	}
	
	
	public static int[] mergeSort(int[]arrayToSort) {
		if(arrayToSort.length <=1) {
			return arrayToSort;
		}
		else {
			BinaryTree<int[]> tree = new DefaultBinaryTree<>(arrayToSort);
			divide(tree.getRoot());
			mergeNodes(tree.getRoot());
			return tree.getRoot().getData();
		}
	}
	
	@Override
	public int[] sort(int[] arrayToSort) {
		return mergeSort(arrayToSort);
	}
	
}
