
public class InsertionSort implements Sorter {
	
	public static int[] insertionSort(int[] arrayToSort) {
		for(int i=0;i<arrayToSort.length;i++) {
			int j=i-1;
			while(j>=0) {
				if(arrayToSort[i]<arrayToSort[j]) {
					int greaterInt = arrayToSort[j];
					arrayToSort[j] = arrayToSort[i];
					arrayToSort[i] = greaterInt;
					i--;
				}
				j--;
			}
		}
		return arrayToSort;
	}
	
	
	@Override
	public  int[] sort(int[] arrayToSort) {
		return insertionSort(arrayToSort);
	}

}
