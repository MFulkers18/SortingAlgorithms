

public class DefaultBinarySearchTree<T> extends DefaultBinaryTree<T> implements BinaryTree<T>, BinarySearchTree<T> {

	DefaultBinarySearchTree(BinaryTreeNode<T> root) {
		super(root);
	}

	DefaultBinarySearchTree(){};
	
	
	@Override
	public void insert(T data) {
		// TODO Auto-generated method stub
	}

	@Override
	public BinaryTreeNode<T> search(T data) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public T minElement() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public T maxElemenmt() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BinaryTreeNode<T> predecessor(BinaryTreeNode<T> node) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BinaryTreeNode<T> sucessor(BinaryTreeNode<T> node) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void delete(BinaryTreeNode<T> node) {
		if(node.isLeaf()) {
			node=null;
		}
		else {
			BinaryTreeNode<T> tempNode = new DefaultBinaryTreeNode<>();
			
			if(node.getLeftChild()!=null && node.getRightChild()!=null) {
				tempNode.setData(node.getRightChild().getData());
				tempNode.setLeftChild(node.getLeftChild());
				tempNode.setRightChild(node.getRightChild().getRightChild());
			}
			else {
				if(node.getLeftChild()==null) {
					tempNode.setData(node.getRightChild().getData());
					tempNode.setRightChild(node.getRightChild().getRightChild());
				}
				else {
					tempNode.setData(node.getLeftChild().getData());
					tempNode.setRightChild(node.getLeftChild().getRightChild());
				}
				node = tempNode;
			}
		}
	}


}
