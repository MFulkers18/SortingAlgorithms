

public class DefaultBinaryTreeNode<T> implements BinaryTreeNode<T> {
	private T data;
	private BinaryTreeNode<T> leftChild;
	private BinaryTreeNode<T> rightChild;
	
	DefaultBinaryTreeNode(T data, BinaryTreeNode<T> leftChild, BinaryTreeNode<T> rightChild){
		this.data = data;
		this.leftChild = leftChild;
		this.rightChild = rightChild;
	}
	
	DefaultBinaryTreeNode(T data){
		this.data = data;
	}
	
	
	DefaultBinaryTreeNode(T rootData, T leftChildData, T rightChildData){
		data = rootData;
		BinaryTreeNode<T> leftChild = new DefaultBinaryTreeNode<>(leftChildData);
		BinaryTreeNode<T> rightChild = new DefaultBinaryTreeNode<>(rightChildData);
		setLeftChild(leftChild);
		setRightChild(rightChild);
	}
	
	DefaultBinaryTreeNode(){};
	
	
	@Override
	public T getData() {
		return data ;
	}

	@Override
	public void setData(T data) {
		this.data = data;
	}

	@Override
	public BinaryTreeNode<T> getLeftChild() {
		return leftChild;
	}

	@Override
	public BinaryTreeNode<T> getRightChild() {
		return rightChild;
	}

	@Override
	public void setLeftChild(BinaryTreeNode<T> leftChild) {
		this.leftChild = leftChild;
	}

	@Override
	public void setRightChild(BinaryTreeNode<T> rightChild) {
		this.rightChild = rightChild;
	}

	@Override
	public boolean isLeaf() {
		return (leftChild==null && rightChild==null);
	}

}
