

public interface Sorter {
	public int[] sort(int[] arrayToSort);
}
