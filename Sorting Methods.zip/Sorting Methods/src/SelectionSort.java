
public class SelectionSort implements Sorter {
	
	public static int[] selectionSort(int[] arrayToSort) {
		for(int i = 0;i<arrayToSort.length-1;i++) {
			int j = i;
			int k = i+1;
			boolean newMinFound=false;
			
			while(k<arrayToSort.length) {
				if(arrayToSort[j]>arrayToSort[k]) {
					newMinFound=true;
					j++;
				}
				k++;
			}
			
			if(newMinFound) {
				int currentMin = arrayToSort[j];
				arrayToSort[j] = arrayToSort[i];
				arrayToSort[i]= currentMin;
			}
		}
		return arrayToSort;
	}
	
	
	@Override
	public int[] sort(int[] arrayToSort) {
		return selectionSort(arrayToSort);
	}
}
