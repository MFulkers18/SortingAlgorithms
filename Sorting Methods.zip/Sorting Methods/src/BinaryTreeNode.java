

public interface BinaryTreeNode<T> {
	public T getData();
	
	public void setData(T data);
	
	public BinaryTreeNode<T> getLeftChild();
	
	public BinaryTreeNode<T> getRightChild();
	
	public void setLeftChild(BinaryTreeNode<T> leftChild);
	
	public void setRightChild(BinaryTreeNode<T> rightChild);
	
	public boolean isLeaf();
}
