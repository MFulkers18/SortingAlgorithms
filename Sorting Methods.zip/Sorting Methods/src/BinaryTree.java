

public interface BinaryTree<T> {
	public BinaryTreeNode<T> getRoot();
	
	public void setRoot(BinaryTreeNode<T> root);
	
	public boolean isEmpty();
	
	public LinkedList<T> preorderTraversal();
	
	public LinkedList<T> inorderTraversal();
	
	public LinkedList<T> postorderTraversal();
	
	public String preorderString();
	
	public String inorderString();
	
	public String postorderString();
	
	public void rightRotation();
	
	public void leftRotation();
	
}
