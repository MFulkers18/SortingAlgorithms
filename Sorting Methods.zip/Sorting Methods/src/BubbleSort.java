
public class BubbleSort implements Sorter{
	
	public static int[] bubbleSort(int[] arrayToSort) {
		
		for(int i=0;i<arrayToSort.length;i++) {
			int j = i;
			int k = i+1;
			while(j>=0 && k<arrayToSort.length) {
				if(arrayToSort[j]>arrayToSort[k]) {
					int greaterInt = arrayToSort[j];
					arrayToSort[j] = arrayToSort[k];
					arrayToSort[k] = greaterInt;
					j--;
					k--;
				}
				else {
					j++;
					k++;
				}
			}
			
		}
		return arrayToSort;
	}
	
	
	@Override
	public int[] sort(int[] arrayToSort) {
		return arrayToSort;
	}
}
