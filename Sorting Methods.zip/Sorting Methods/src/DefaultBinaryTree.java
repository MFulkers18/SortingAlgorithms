

public class DefaultBinaryTree<T> implements BinaryTree<T> {
	private BinaryTreeNode<T> root = new DefaultBinaryTreeNode<>();
	
	
	DefaultBinaryTree(T data){
		root.setData(data);
	}
	
	DefaultBinaryTree(BinaryTreeNode<T> root){
		this.root = root;
	}
	
	DefaultBinaryTree(){};
	
	
	@Override
	public BinaryTreeNode<T> getRoot() {
		return root;
	}

	@Override
	public void setRoot(BinaryTreeNode<T> root) {
		this.root = root;
	}

	@Override
	public boolean isEmpty() {
		return (root.getData()==null && root.getLeftChild()==null && root.getRightChild()==null);
	}

	
	private LinkedList<T> preorderTraversal(BinaryTreeNode<T> node, LinkedList<T> list){
		if(node==null) {
			return null;
		}
		else {
			list.insertLast(node.getData());
			preorderTraversal(node.getLeftChild(),list);
			preorderTraversal(node.getRightChild(),list);
		}
		return list;
	}
	
	
	@Override
	public LinkedList<T> preorderTraversal() {
		LinkedList<T> list = new LinkedList<>();
		return preorderTraversal(root,list);
	}

	
	private LinkedList<T> inorderTraversal(BinaryTreeNode<T> node, LinkedList<T> list){
		if(node==null) {
			return null;
		}
		else {
			inorderTraversal(node.getLeftChild(),list);
			list.insertLast(node.getData());
			inorderTraversal(node.getRightChild(),list);
		}
		return list;
	}
	
	
	@Override
	public LinkedList<T> inorderTraversal() {
		LinkedList<T> list = new LinkedList<>();
		return inorderTraversal(root,list);
	}

	
	private LinkedList<T> postorderTraversal(BinaryTreeNode<T> node, LinkedList<T> list){
		if(node==null) {
			return null;
		}
		else {
			postorderTraversal(node.getLeftChild(),list);
			postorderTraversal(node.getRightChild(),list);
			list.insertLast(node.getData());
		}
		return list;
	}
	
	
	@Override
	public LinkedList<T> postorderTraversal() {
		LinkedList<T> list = new LinkedList<>();
		return postorderTraversal(root,list);
	}

	
	@Override
	public String preorderString() {
		return preorderTraversal().toString();
	}

	@Override
	public String inorderString() {
		return inorderTraversal().toString();
	}

	@Override
	public String postorderString() {
		return postorderTraversal().toString();
	}

	@Override
	public void rightRotation() {
		BinaryTreeNode<T> tempNode = root.getLeftChild();
		root.setLeftChild(tempNode.getRightChild());
		tempNode.setRightChild(root);
		root = tempNode;
		
	}

	@Override
	public void leftRotation() {
		BinaryTreeNode<T> tempNode= root.getRightChild();
		root.setRightChild(tempNode.getLeftChild());
		tempNode.setLeftChild(root);
		root = tempNode;
		
	}

}
